-- AlterTable
ALTER TABLE `sales_return` ADD COLUMN `narration` VARCHAR(255) NULL;
