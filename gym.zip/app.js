import express from "express";
import planRoutes from "./src/routes/plan.routes.js";
import rolesRoutes from "./src/routes/role.routes.js";
import authRoutes from "./src/routes/auth.Routes.js";
import accountRoutes from "./src/routes/account.routes.js";
import vendorRoutes from "./src/routes/vendor.routes.js";
import transectionRoutes from "./src/routes/transaction.routes.js";
import warehouseReoutes from "./src/routes/wareHouses.routes.js";
import itemCategoryRoutes from "./src/routes/itemCategory.routes.js";
import productRoutes from "./src/routes/product.routes.js";
import uomRoutes from "./src/routes/uom.routes.js";
import unitDetailRoutes from "./src/routes/unitdetail.routes.js";
import serviceRoutes from "./src/routes/service.routes.js";
import voucherRoutes from "./src/routes/voucher.routes.js";
import stockTransferRoutes from "./src/routes/stockTransfer.routes.js";
import inventoryadjustmentRoutes from "./src/routes/inventoryadjustment.Routes.js";
import expenseVoucherRouter from "./src/routes/expensevoucher.Routes.js";
import incomeVoucherRoutes from "./src/routes/incomeVoucher.routes.js";
import contravouchersRoutes from "./src/routes/contraVoucher.routes.js";
import taxClassRoutes from "./src/routes/taxClassRoutes.js";
import posinvoiceRoutes from "./src/routes/posinvoiceroutes.js";
import purchase from "./src/routes/purchase.routes.js";
import salesreturn from "./src/routes/salesreturn.routes.js";
import salesorder from "./src/routes/salesorder.routes.js";
import salesReport from "./src/routes/salesReport.routes.js";
import purchaseReport from "./src/routes/purchaseReport.routes.js";
import company from "./src/routes/companies.Routes.js";
import purchaseOrder from "./src/routes/purchaseOrderRoutes.js";
import inventoryRoutes from "./src/routes/inventory.routes.js"
import planRequestRoutes from "./src/routes/requestforplan.Routes.js"
import posReportRoutes from "./src/routes/posReport.routes.js"
import vatReportRoutes from "./src/routes/vatReport.routes.js"
import ledgerReport from "./src/routes/ledgerReport.routes.js"
import balanceSheetRoutes from "./src/routes/balncesheet.routes.js"
import getTrialBalanceRoutes from "./src/routes/getTrialBalance.routes.js"
import cashflowRoutes from "./src/routes/cashflow.routes.js"
import dayBookRoutes from "./src/routes/dayBook.routes.js"
import taxReportRoutes from "./src/routes/taxReport.routes.js"


const router = express.Router();

router.use("/plans", planRoutes);
router.use("/user-roles", rolesRoutes);
router.use("/auth", authRoutes);
router.use("/account", accountRoutes);
router.use("/vendorCustomer", vendorRoutes);
router.use("/transactions", transectionRoutes);
router.use("/warehouses", warehouseReoutes);
router.use("/item-categories", itemCategoryRoutes);
router.use("/products", productRoutes);
router.use("/uoms", uomRoutes);
router.use("/unit-details", unitDetailRoutes);
router.use("/services", serviceRoutes);
router.use("/voucher", voucherRoutes);
router.use("/stocktransfers", stockTransferRoutes);
router.use("/inventoryadjustment", inventoryadjustmentRoutes);
router.use("/expensevoucher", expenseVoucherRouter);
router.use("/income-vouchers", incomeVoucherRoutes);
router.use("/contravouchers", contravouchersRoutes);
router.use("/taxclasses", taxClassRoutes);
router.use("/posinvoice", posinvoiceRoutes);
router.use("/pos-report", posReportRoutes);
router.use("/vat-report",vatReportRoutes);
router.use("/", purchase);
router.use("/sales-return", salesreturn);
router.use("/sales-order", salesorder);
router.use("/sales-reports", salesReport);
router.use("/ledger-report", ledgerReport);
router.use("/purchase-reports", purchaseReport);
router.use("/cashflow-reports", cashflowRoutes);
router.use("/tax-report",taxReportRoutes);
router.use("/daybook", dayBookRoutes);
router.use("/balance-sheet", balanceSheetRoutes);
router.use("/trial-balance", getTrialBalanceRoutes);
router.use("/companies", company);
router.use("/purchase-orders", purchaseOrder);
router.use("/inventory", inventoryRoutes);
router.use("/planreq", planRequestRoutes);

export default router;
