-- AlterTable
ALTER TABLE `users` ADD COLUMN `user_role` VARCHAR(191) NULL;
